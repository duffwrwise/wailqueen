"""Central configuration. Edit values here or override them in the .env file."""
import os

from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN", "")
PREFIX = os.getenv("BOT_PREFIX", "!")
BOT_NAME = os.getenv("BOT_NAME", "Wailord Premium")
AUTO_SYNC = os.getenv("AUTO_SYNC", "1") == "1"  # sync slash commands on startup

# Embed colors (hex integers)
ACCENT = 0x5865F2

# Optional support link shown in /botinfo. Leave empty to hide it.
SUPPORT_URL = os.getenv("SUPPORT_URL", "")

# Channels referenced inside the default welcome message
PROTOCOL_CHANNEL_ID = int(os.getenv("PROTOCOL_CHANNEL_ID", "0"))
INFO_BOARD_CHANNEL_ID = int(os.getenv("INFO_BOARD_CHANNEL_ID", "0"))

# ---------------- Welcome message defaults (easy to edit) ----------------
# Placeholders: {user} {username} {server} {count}
WELCOME_CONTENT = "Warm greetings, {user}! 🕸️"
WELCOME_TITLE = "Welcome to the Spider's Web community."
WELCOME_DESCRIPTION = (
    "To ensure a productive environment for all members, please review our "
    "**Community Guidelines** in {protocol}. "
    "For a comprehensive overview of our resources and objectives, "
    "additional documentation is available in {info_board}."
)
WELCOME_COLOR = "random"  # "random" or a hex value such as "#9B59B6"
RANDOM_COLORS = [0x9B59B6, 0x9EFF4A, 0xA3204F, 0x3498DB, 0xE67E22, 0x1ABC9C]

# ---------------- Emojis used in /userinfo ----------------
EMOJI = {
    "badges": "🏅",
    "none": "❌",
    "roles": "🎭",
    "permissions": "🔐",
    "activity": "🎮",
    "online": "🟢",
    "idle": "🟡",
    "dnd": "🔴",
    "offline": "⚫",
}
