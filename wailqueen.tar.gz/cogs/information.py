from __future__ import annotations

import platform
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

import config
from utils import helpers
from utils.helpers import relative, stamp
from utils.ui import make_embed


class Information(commands.Cog):
    """Profile, server and bot information."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    def _uptime(self) -> int:
        return int((discord.utils.utcnow() - self.bot.started_at).total_seconds())  # type: ignore[attr-defined]

    # ------------------------------------------------------------------ ping
    @commands.hybrid_command(name="ping", description="Show the bot latency and uptime.")
    async def ping(self, ctx: commands.Context) -> None:
        embed = make_embed(
            "Pong",
            f"**Gateway latency:** `{round(self.bot.latency * 1000)} ms`\n"
            f"**Uptime:** `{helpers.humanize_seconds(self._uptime())}`",
        )
        await ctx.send(embed=embed)

    # --------------------------------------------------------------- botinfo
    @commands.hybrid_command(
        name="botinfo",
        aliases=["bi", "about", "stats"],
        description="Show information and statistics about the bot.",
    )
    async def botinfo(self, ctx: commands.Context) -> None:
        bot_user = self.bot.user
        assert bot_user is not None

        lines = [
            "### Bot information",
            f"ID: `{bot_user.id}`",
            f"Username: **{bot_user.name}**",
        ]
        if bot_user.discriminator != "0":
            lines.append(f"Discriminator: **{bot_user.discriminator}**")
        lines.append(f"Created: **{relative(bot_user.created_at)}**")
        lines.append(f"Mention: {bot_user.mention}")

        if ctx.guild and ctx.guild.me:
            me = ctx.guild.me
            lines += [
                "",
                "### Member information",
                f"Added: **{relative(me.joined_at)}**",
                f"Roles: {helpers.role_list(helpers.member_roles(me))}",
            ]

        users = sum(guild.member_count or 0 for guild in self.bot.guilds)
        command_count = len({c.qualified_name for c in self.bot.commands if not c.hidden})
        lines += [
            "",
            "### Statistics",
            f"Servers: **{len(self.bot.guilds):,}**",
            f"Users: **{users:,}**",
            f"Commands: **{command_count}**",
            f"Latency: **{round(self.bot.latency * 1000)} ms**",
            f"Uptime: **{helpers.humanize_seconds(self._uptime())}**",
            f"Python: **{platform.python_version()}** • discord.py: **{discord.__version__}**",
        ]
        if config.SUPPORT_URL:
            lines += ["", f"[Support server]({config.SUPPORT_URL})"]

        embed = make_embed(description="\n".join(lines))
        embed.set_author(name=f"Bot: {bot_user}", icon_url=bot_user.display_avatar.url)
        await ctx.send(embed=embed)

    # -------------------------------------------------------------- userinfo
    @commands.hybrid_command(
        name="userinfo",
        aliases=["ui", "whois", "profile"],
        description="Show detailed information about a member.",
    )
    @app_commands.describe(member="The member to look up. Defaults to you.")
    @commands.guild_only()
    async def userinfo(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        assert ctx.guild is not None
        member = member or ctx.author  # type: ignore[assignment]
        assert isinstance(member, discord.Member)

        e = config.EMOJI
        roles = helpers.member_roles(member)
        badges = helpers.badge_text(member)
        status_emoji = e[helpers.STATUS_KEYS.get(member.status, "offline")]
        activity = helpers.activity_text(member)

        lines = [
            f"**{member.display_name}** ({member.mention})",
            f"ID: `{member.id}`",
            f"Account created: {stamp(member.created_at)}",
            f"Joined server: {stamp(member.joined_at)}",
        ]
        if member.premium_since:
            lines.append(f"Boosting since: {stamp(member.premium_since)}")
        lines += [
            "",
            f"### {e['badges']} Badges",
            f"{e['none'] + ' ' if badges == 'None' else ''}{badges}",
            f"### {e['roles']} Roles ({len(roles)})",
            helpers.role_list(roles),
            f"### {e['permissions']} Permissions",
            helpers.permission_summary(member),
            f"### {status_emoji} Status",
            helpers.STATUS_NAMES.get(member.status, "Offline"),
            f"### {e['activity']} Activity",
            activity,
        ]

        embed = make_embed(
            description="\n".join(lines),
            color=member.color.value or config.ACCENT,
            thumbnail=member.display_avatar.url,
            footer=f"User ID: {member.id} • Server: {ctx.guild.name}",
        )
        await ctx.send(embed=embed)

    # ------------------------------------------------------------ serverinfo
    @commands.hybrid_command(
        name="serverinfo",
        aliases=["si", "guildinfo"],
        description="Show information about this server.",
    )
    @commands.guild_only()
    async def serverinfo(self, ctx: commands.Context) -> None:
        guild = ctx.guild
        assert guild is not None

        embed = make_embed(
            guild.name,
            thumbnail=guild.icon.url if guild.icon else None,
            image=guild.banner.url if guild.banner else None,
            footer=f"Server ID: {guild.id}",
        )
        embed.add_field(
            name="General",
            value=f"Owner: <@{guild.owner_id}>\nCreated: {stamp(guild.created_at)}",
            inline=False,
        )
        embed.add_field(
            name="Counts",
            value=(
                f"Members: **{guild.member_count or 0:,}**\n"
                f"Roles: **{max(len(guild.roles) - 1, 0)}**\n"
                f"Channels: **{len(guild.text_channels)}** text • **{len(guild.voice_channels)}** voice\n"
                f"Emojis: **{len(guild.emojis)}**"
            ),
            inline=True,
        )
        embed.add_field(
            name="Boosts",
            value=(
                f"Level: **{guild.premium_tier}**\n"
                f"Boosts: **{guild.premium_subscription_count}**\n"
                f"Verification: **{guild.verification_level.name.replace('_', ' ').title()}**"
            ),
            inline=True,
        )
        await ctx.send(embed=embed)

    # ---------------------------------------------------------------- avatar
    @commands.hybrid_command(
        name="avatar",
        aliases=["av", "pfp"],
        description="Show a user's avatar in full size.",
    )
    @app_commands.describe(user="The user whose avatar to show. Defaults to you.")
    async def avatar(self, ctx: commands.Context, user: Optional[discord.User] = None) -> None:
        user = user or ctx.author  # type: ignore[assignment]
        assert user is not None
        asset = user.display_avatar

        embed = make_embed(
            f"Avatar of {user.name}:",
            helpers.format_links(asset),
            image=helpers.asset_url(asset),
        )
        await ctx.send(embed=embed)

    # ---------------------------------------------------------------- banner
    @commands.hybrid_command(
        name="banner",
        aliases=["bn"],
        description="Show a user's profile banner.",
    )
    @app_commands.describe(user="The user whose banner to show. Defaults to you.")
    async def banner(self, ctx: commands.Context, user: Optional[discord.User] = None) -> None:
        target = user or ctx.author
        fetched = await self.bot.fetch_user(target.id)

        if fetched.banner:
            embed = make_embed(
                f"Banner of {fetched.name}:",
                helpers.format_links(fetched.banner),
                image=helpers.asset_url(fetched.banner),
            )
        else:
            embed = make_embed(f"Banner of {fetched.name}:", "This user does not have a profile banner.")
        await ctx.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Information(bot))
