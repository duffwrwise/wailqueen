from __future__ import annotations

import random
import sqlite3
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

import config

KEYS = ["channel_id", "content", "title", "description", "color", "enabled"]


def _channel_ref(channel_id: int, fallback: str) -> str:
    return f"<#{channel_id}>" if channel_id else f"#{fallback}"


def default_description() -> str:
    return config.WELCOME_DESCRIPTION.replace(
        "{protocol}", _channel_ref(config.PROTOCOL_CHANNEL_ID, "protocol")
    ).replace("{info_board}", _channel_ref(config.INFO_BOARD_CHANNEL_ID, "info-board"))


def fmt(text: str, member: discord.Member) -> str:
    return (
        text.replace("{user}", member.mention)
        .replace("{username}", member.display_name)
        .replace("{server}", member.guild.name)
        .replace("{count}", str(member.guild.member_count))
    )


def parse_color(value: str) -> discord.Color:
    value = (value or "random").strip()
    if value.lower() == "random":
        return discord.Color(random.choice(config.RANDOM_COLORS))
    try:
        return discord.Color(int(value.lstrip("#"), 16))
    except ValueError:
        return discord.Color(random.choice(config.RANDOM_COLORS))


class WelcomeEditModal(discord.ui.Modal, title="Edit Welcome Message"):
    def __init__(self, cog: "Welcome", cfg: dict) -> None:
        super().__init__()
        self.cog = cog
        self.content_in = discord.ui.TextInput(
            label="Message text (above the embed)",
            default=cfg["content"],
            max_length=500,
            required=False,
        )
        self.title_in = discord.ui.TextInput(
            label="Embed title", default=cfg["title"], max_length=256
        )
        self.desc_in = discord.ui.TextInput(
            label="Embed description",
            default=cfg["description"],
            style=discord.TextStyle.paragraph,
            max_length=4000,
        )
        self.color_in = discord.ui.TextInput(
            label="Color (random or #HEX)",
            default=cfg["color"],
            max_length=10,
            required=False,
        )
        for item in (self.content_in, self.title_in, self.desc_in, self.color_in):
            self.add_item(item)

    async def on_submit(self, interaction: discord.Interaction) -> None:
        assert interaction.guild_id is not None and isinstance(interaction.user, discord.Member)
        self.cog.save_cfg(
            interaction.guild_id,
            content=self.content_in.value or "",
            title=self.title_in.value,
            description=self.desc_in.value,
            color=self.color_in.value or "random",
        )
        content, embed = self.cog.build_message(interaction.user)
        await interaction.response.send_message("Welcome message updated. Preview:", ephemeral=True)
        await interaction.followup.send(content=content, embed=embed, ephemeral=True)


class Welcome(commands.Cog):
    """Automatic welcome messages with an editable embed."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.db = sqlite3.connect("welcome.db")
        self.db.execute(
            """CREATE TABLE IF NOT EXISTS welcome (
                guild_id INTEGER PRIMARY KEY,
                channel_id INTEGER,
                content TEXT,
                title TEXT,
                description TEXT,
                color TEXT,
                enabled INTEGER DEFAULT 1
            )"""
        )
        self.db.commit()

    async def cog_unload(self) -> None:
        self.db.close()

    # ------------------------------------------------------------- storage
    def get_cfg(self, guild_id: int) -> dict:
        row = self.db.execute(
            "SELECT channel_id, content, title, description, color, enabled "
            "FROM welcome WHERE guild_id=?",
            (guild_id,),
        ).fetchone()
        if row:
            return dict(zip(KEYS, row))
        return {
            "channel_id": None,
            "content": config.WELCOME_CONTENT,
            "title": config.WELCOME_TITLE,
            "description": default_description(),
            "color": config.WELCOME_COLOR,
            "enabled": 1,
        }

    def save_cfg(self, guild_id: int, **changes) -> None:
        cfg = self.get_cfg(guild_id)
        cfg.update(changes)
        self.db.execute(
            "INSERT OR REPLACE INTO welcome VALUES (?,?,?,?,?,?,?)",
            (
                guild_id,
                cfg["channel_id"],
                cfg["content"],
                cfg["title"],
                cfg["description"],
                cfg["color"],
                cfg["enabled"],
            ),
        )
        self.db.commit()

    # ------------------------------------------------------------- building
    def build_message(self, member: discord.Member) -> tuple[Optional[str], discord.Embed]:
        cfg = self.get_cfg(member.guild.id)
        embed = discord.Embed(
            title=fmt(cfg["title"], member),
            description=fmt(cfg["description"], member),
            color=parse_color(cfg["color"]),
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        return (fmt(cfg["content"], member) or None), embed

    def resolve_channel(self, guild: discord.Guild, cfg: dict) -> Optional[discord.TextChannel]:
        me = guild.me
        if cfg["channel_id"]:
            channel = guild.get_channel(cfg["channel_id"])
            if isinstance(channel, discord.TextChannel):
                return channel
        for channel in guild.text_channels:
            if "welcome" in channel.name.lower() and channel.permissions_for(me).send_messages:
                return channel
        system = guild.system_channel
        if system and system.permissions_for(me).send_messages:
            return system
        return None

    # --------------------------------------------------------------- events
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        if member.bot:
            return
        cfg = self.get_cfg(member.guild.id)
        if not cfg["enabled"]:
            return
        channel = self.resolve_channel(member.guild, cfg)
        if channel is None:
            return
        content, embed = self.build_message(member)
        await channel.send(
            content=content,
            embed=embed,
            allowed_mentions=discord.AllowedMentions(users=[member]),
        )

    # ------------------------------------------------------- slash commands
    @app_commands.command(name="welcome-setup", description="Choose the welcome channel.")
    @app_commands.describe(channel="Channel where welcome messages are sent.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def welcome_setup(self, interaction: discord.Interaction, channel: discord.TextChannel) -> None:
        self.save_cfg(interaction.guild_id, channel_id=channel.id)  # type: ignore[arg-type]
        await interaction.response.send_message(
            f"Welcome channel set to {channel.mention}.", ephemeral=True
        )

    @app_commands.command(name="welcome-edit", description="Edit the welcome message.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def welcome_edit(self, interaction: discord.Interaction) -> None:
        cfg = self.get_cfg(interaction.guild_id)  # type: ignore[arg-type]
        await interaction.response.send_modal(WelcomeEditModal(self, cfg))

    @app_commands.command(name="welcome-test", description="Preview the welcome message.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def welcome_test(self, interaction: discord.Interaction) -> None:
        assert isinstance(interaction.user, discord.Member)
        content, embed = self.build_message(interaction.user)
        await interaction.response.send_message(content=content, embed=embed, ephemeral=True)

    @app_commands.command(name="welcome-toggle", description="Turn welcome messages on or off.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def welcome_toggle(self, interaction: discord.Interaction) -> None:
        new = 0 if self.get_cfg(interaction.guild_id)["enabled"] else 1  # type: ignore[arg-type]
        self.save_cfg(interaction.guild_id, enabled=new)  # type: ignore[arg-type]
        await interaction.response.send_message(
            f"Welcome messages are now **{'ON' if new else 'OFF'}**.", ephemeral=True
        )

    @app_commands.command(name="welcome-reset", description="Restore the default welcome message.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.guild_only()
    async def welcome_reset(self, interaction: discord.Interaction) -> None:
        self.save_cfg(
            interaction.guild_id,  # type: ignore[arg-type]
            content=config.WELCOME_CONTENT,
            title=config.WELCOME_TITLE,
            description=default_description(),
            color=config.WELCOME_COLOR,
        )
        await interaction.response.send_message("Welcome message reset to the default.", ephemeral=True)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Welcome(bot))
