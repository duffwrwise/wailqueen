from __future__ import annotations

import logging

import discord
from discord.ext import commands

import config
from utils.helpers import pretty_permission

log = logging.getLogger("premium-bot.errors")


class Errors(commands.Cog):
    """Global error handling."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @commands.Cog.listener()
    async def on_command_error(self, ctx: commands.Context, error: commands.CommandError) -> None:
        if isinstance(error, (commands.CommandInvokeError, commands.HybridCommandError)):
            error = error.original  # type: ignore[assignment]

        if isinstance(error, commands.CommandNotFound):
            return

        usage = ""
        if ctx.command is not None:
            usage = f"{config.PREFIX}{ctx.command.qualified_name} {ctx.command.signature}".strip()

        if isinstance(error, commands.MissingRequiredArgument):
            message = f"Missing required argument: {error.param.name}\nUsage: `{usage}`"
        elif isinstance(error, commands.BadArgument):
            message = f"{error}\nUsage: `{usage}`"
        elif isinstance(error, commands.MissingPermissions):
            perms = ", ".join(pretty_permission(p) for p in error.missing_permissions)
            message = f"You need the following permissions to use this command: {perms}"
        elif isinstance(error, commands.BotMissingPermissions):
            perms = ", ".join(pretty_permission(p) for p in error.missing_permissions)
            message = f"I need the following permissions to run this command: {perms}"
        elif isinstance(error, commands.CommandOnCooldown):
            message = f"This command is on cooldown. Try again in {error.retry_after:.1f}s."
        elif isinstance(error, commands.NoPrivateMessage):
            message = "This command can only be used inside a server."
        elif isinstance(error, (commands.NotOwner, commands.CheckFailure)):
            message = "You are not allowed to use this command."
        elif isinstance(error, commands.UserInputError):
            message = f"{error}\nUsage: `{usage}`"
        else:
            log.error("Unhandled error in command %s", ctx.command, exc_info=error)
            message = "An unexpected error occurred. Please try again in a moment."

        try:
            await ctx.send(message, ephemeral=True)
        except discord.HTTPException:
            log.warning("Could not deliver the error message for %s", ctx.command)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Errors(bot))
