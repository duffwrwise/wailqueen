from __future__ import annotations

import difflib
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands

import config
from utils.ui import make_embed


class Help(commands.Cog):
    """Command browser."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    def _visible(self) -> list[commands.Command]:
        return [c for c in self.bot.commands if not c.hidden]

    def _slash_only(self) -> list[app_commands.Command]:
        prefixed = {c.name for c in self.bot.commands}
        return [
            c
            for c in self.bot.tree.get_commands()
            if isinstance(c, app_commands.Command) and c.name not in prefixed
        ]

    @commands.hybrid_command(
        name="help",
        aliases=["h", "commands"],
        description="Browse every command or get details about one.",
    )
    @app_commands.describe(command="A command name to view details for.")
    async def help_command(self, ctx: commands.Context, *, command: Optional[str] = None) -> None:
        if command:
            await self._send_detail(ctx, command.strip().lstrip(config.PREFIX).lstrip("/"))
        else:
            await self._send_overview(ctx)

    @help_command.autocomplete("command")
    async def help_autocomplete(
        self, interaction: discord.Interaction, current: str
    ) -> list[app_commands.Choice[str]]:
        names = {c.qualified_name for c in self._visible()} | {c.name for c in self._slash_only()}
        current = current.lower()
        return [app_commands.Choice(name=n, value=n) for n in sorted(names) if current in n][:25]

    async def _send_overview(self, ctx: commands.Context) -> None:
        embed = make_embed(
            f"{config.BOT_NAME} Help",
            f"Prefix: `{config.PREFIX}` • Slash commands are supported too.\n"
            f"Use `{config.PREFIX}help <command>` for details about a command.",
            thumbnail=self.bot.user.display_avatar.url if self.bot.user else None,
            footer=f"Requested by {ctx.author.name}",
        )

        for cog in sorted(self.bot.cogs.values(), key=lambda c: c.qualified_name):
            items = sorted(
                (c for c in cog.get_commands() if not c.hidden), key=lambda c: c.qualified_name
            )
            if not items:
                continue
            embed.add_field(
                name=f"{cog.qualified_name} ({len(items)})",
                value=", ".join(f"`{c.qualified_name}`" for c in items),
                inline=False,
            )

        slash = sorted(self._slash_only(), key=lambda c: c.name)
        if slash:
            embed.add_field(
                name=f"Slash Only ({len(slash)})",
                value=", ".join(f"`/{c.name}`" for c in slash),
                inline=False,
            )
        await ctx.send(embed=embed)

    async def _send_detail(self, ctx: commands.Context, name: str) -> None:
        cmd = self.bot.get_command(name.lower())

        if cmd is None or cmd.hidden:
            slash = next((c for c in self._slash_only() if c.name == name.lower()), None)
            if slash is not None:
                embed = make_embed(
                    f"/{slash.name}",
                    f"{slash.description}\n\n**Usage:** `/{slash.name}`\n**Type:** Slash command only",
                )
                await ctx.send(embed=embed)
                return

            known = sorted({c.qualified_name for c in self._visible()} | {c.name for c in self._slash_only()})
            close = difflib.get_close_matches(name.lower(), known, n=3, cutoff=0.5)
            message = f"No command named `{name}` was found."
            if close:
                message += "\nDid you mean: " + ", ".join(f"`{c}`" for c in close)
            await ctx.send(message, ephemeral=True)
            return

        usage = f"{config.PREFIX}{cmd.qualified_name} {cmd.signature}".strip()
        lines = [cmd.description or cmd.short_doc or "No description provided.", "", f"**Usage:** `{usage}`"]
        if cmd.aliases:
            lines.append("**Aliases:** " + ", ".join(f"`{a}`" for a in cmd.aliases))
        if cmd.cog:
            lines.append(f"**Category:** {cmd.cog.qualified_name}")

        await ctx.send(embed=make_embed(cmd.qualified_name, "\n".join(lines), footer="<required> • [optional]"))


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Help(bot))
