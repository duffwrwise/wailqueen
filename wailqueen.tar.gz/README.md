# Wailord Premium

Information and welcome bot for discord.py 2.6+. Classic embeds, prefix and slash commands.

## Commands
| Command | Aliases | Description |
|---|---|---|
| help [command] | h, commands | Browse all commands or see details for one |
| botinfo | bi, about, stats | Bot information, member information and statistics |
| userinfo [member] | ui, whois, profile | Badges, roles, permissions, status and activity |
| serverinfo | si, guildinfo | Server overview |
| avatar [user] | av, pfp | Full-size avatar with PNG / JPG / WEBP links |
| banner [user] | bn | Profile banner |
| ping | | Gateway latency and uptime |

### Welcome system (slash commands only, needs Manage Server)
| Command | Description |
|---|---|
| /welcome-setup channel | Choose the welcome channel |
| /welcome-edit | Popup to edit text, title, description and color |
| /welcome-test | Preview the message |
| /welcome-toggle | Turn welcome messages on or off |
| /welcome-reset | Restore the default message |

By default the welcome message works without any setup: it posts in a channel whose name contains
"welcome", or in the server's system channel. Use /welcome-setup to pick a specific channel.
Placeholders: `{user}` `{username}` `{server}` `{count}`. Color: `random` or a hex value like `#9B59B6`.

## Setup
1. Python 3.11 or newer.
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`, set `DISCORD_TOKEN`, and optionally the two channel IDs used in the default welcome text.
4. In the Developer Portal, open Bot and enable Presence, Server Members and Message Content intents.
5. Invite the bot with the `bot` and `applications.commands` scopes (permissions: Send Messages, Embed Links).
6. `python main.py`

## Customize
Everything editable lives in `config.py`: prefix, colors, emojis, and the default welcome text.
