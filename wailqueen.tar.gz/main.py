import logging

import discord
from discord.ext import commands

import config

log = logging.getLogger("premium-bot")

EXTENSIONS = (
    "cogs.information",
    "cogs.welcome",
    "cogs.help",
    "cogs.errors",
)


class PremiumBot(commands.Bot):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.members = True          # Server Members Intent (Developer Portal)
        intents.presences = True        # Presence Intent (Developer Portal)
        intents.message_content = True  # Message Content Intent (Developer Portal)

        super().__init__(
            command_prefix=commands.when_mentioned_or(config.PREFIX),
            intents=intents,
            help_command=None,
            case_insensitive=True,
            strip_after_prefix=True,
            allowed_mentions=discord.AllowedMentions.none(),
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name=f"{config.PREFIX}help",
            ),
        )
        self.started_at = discord.utils.utcnow()

    async def setup_hook(self) -> None:
        for extension in EXTENSIONS:
            await self.load_extension(extension)
            log.info("Loaded extension %s", extension)

        if config.AUTO_SYNC:
            synced = await self.tree.sync()
            log.info("Synced %d slash commands", len(synced))

    async def on_ready(self) -> None:
        log.info("Logged in as %s (ID: %s)", self.user, self.user.id if self.user else "unknown")


def main() -> None:
    if not config.TOKEN:
        raise SystemExit("DISCORD_TOKEN is missing. Copy .env.example to .env and set it.")
    PremiumBot().run(config.TOKEN)


if __name__ == "__main__":
    main()
